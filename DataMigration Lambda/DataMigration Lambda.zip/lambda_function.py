import json
import psycopg2
import boto3
import os

client = boto3.client('dynamodb')
connection = psycopg2.connect("user='postgres' password='password123' host='hiadb.cggxgkky2kq4.ap-southeast-2.rds.amazonaws.com' dbname='HIA'")
cursor = connection.cursor()

def dump_table(table_name):
    results = []
    last_evaluated_key = None
    while True:
        if last_evaluated_key:
            response = client.scan(
                TableName=table_name,
                ExclusiveStartKey=last_evaluated_key
            )
        else:
            response = client.scan(TableName=table_name)
        last_evaluated_key = response.get('LastEvaluatedKey')

        results.extend(response['Items'])

        if not last_evaluated_key:
            break
    return results

def migrate_registration():
    dynamoData = dump_table('registration')
    insertQ = """ INSERT INTO registration (id, date, num) VALUES (%s, %s, %s) """
    for row in dynamoData:
        insertRecord = (row['id']['S'], row['date']['N'], row['num']['S'])
        cursor.execute(insertQ, insertRecord)
        connection.commit()

def migrate_positive_registration():
    dynamoData = dump_table('positiveRegistration')
    insertQ = """ INSERT INTO \"positiveRegistration\" (id, date) VALUES (%s, %s) """
    for row in dynamoData:
        insertRecord = (row['id']['S'], row['date']['N'])
        cursor.execute(insertQ, insertRecord)
        connection.commit()

def migrate_gpsPosition():
    dynamoData = dump_table('gpsPosition')
    insertQ = """ INSERT INTO \"gpsPosition\" (idx, date, id, lat, lng) VALUES (%s, %s, %s, %s, %s) """
    for row in dynamoData:
        insertRecord = (row['idx']['N'], row['date']['N'], row['id']['S'], row['lat']['S'], row['lng']['S'])
        cursor.execute(insertQ, insertRecord)
        connection.commit()

def lambda_handler(event, context):
    migrate_registration()
    migrate_positive_registration()
    migrate_gpsPosition()

    return {
        'statusCode': 200,
        'body': json.dumps('Data migrated!')
    }
